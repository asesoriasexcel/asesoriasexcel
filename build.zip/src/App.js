import React from 'react';
import LandingPage from './pages/LandingPage';
import './App.css';

const App = () => {
  return <LandingPage />;
};

export default App;
