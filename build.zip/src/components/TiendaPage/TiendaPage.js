import React from 'react';

const TiendaPage = () => {
  return (
    <div className="cuerpo-page-container">
      <div className="cuerpo-page">
        {/* Contenido de prueba */}
        <p>Este es un ejemplo de contenido en la página de tienda.</p>
      </div>
    </div>
  );
};

export default TiendaPage;
