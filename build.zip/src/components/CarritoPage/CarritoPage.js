// src/pages/CarritoPage.js
import React from 'react';

const CarritoPage = () => {
  return <div>CarritoPage Page</div>;
};

export default CarritoPage;
