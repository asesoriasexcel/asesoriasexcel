// src/pages/ProductoPage.js
import React from 'react';

const ProductoPage = () => {
  return <div>ProductoPage Page</div>;
};

export default ProductoPage;
