// src/pages/ConfirmaCompraPage.js
import React from 'react';

const ConfirmaCompraPage = () => {
  return <div>ConfirmaCompraPage Page</div>;
};

export default ConfirmaCompraPage;
