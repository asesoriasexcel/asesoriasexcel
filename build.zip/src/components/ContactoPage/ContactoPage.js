// src/pages/ContactoPage.js
import React from 'react';

const ContactoPage = () => {
  return <div>ContactoPage Page</div>;
};

export default ContactoPage;
