// src/pages/DisenoPage.js
import React from 'react';

const DisenoPage = () => {
  return <div>DisenoPage Page</div>;
};

export default DisenoPage;
