// src/pages/TerminosCondicionesPage.js
import React from 'react';

const TerminosCondicionesPage = () => {
  return <div>TerminosCondicionesPage Page</div>;
};

export default TerminosCondicionesPage;
